#include <fstream>
#include <istream>
#include <iostream>
#include <string>
#include <vector>
#include "Trie.h"

class GraphSimplify {
private :
    int n, m;
    std::vector<std::vector<int> > edge, tag, revedge, Bucket;
    std::vector<int> label, children;
    Trie T;
public :
    GraphSimplify () { }
    ~ GraphSimplify () { }
    bool loadFromFile(const std::string &path) {
        std::ifstream in(path);
        if(!in.is_open()) {
            return false;
        }
        return loadFromStream(in);
    }

    bool loadFromStream(std::istream &in) {
        if(!(in >> n >> m)) {
            return false;
        }
        edge.resize(n);
        revedge.resize(n);
        for(int i = 0; i < m; ++i) {
            int u = 0, v = 0;
            if(!(in >> u >> v)) {
                return false;
            }
            edge[u].emplace_back(v);
            revedge[v].emplace_back(u);
        }
        return true;
    }

    void simplfy() {
        tag.clear();
        tag.resize(n);
        label.clear();
        label.resize(n);
        Bucket.clear();
        Bucket.resize(n);
        children.clear();
        children.resize(n);
        for(int i = 0; i < n; ++i) {
            children[i] = edge[i].size();
            if(edge[i].empty()) {
                Bucket[0].emplace_back(i);
            }
        }
        for(int k = 0; !Bucket[k].empty(); ++k) {
            std::cout << "Type " << k << ": ";
            for(auto u : Bucket[k]) {
                std::cout << u << ' ';
                for(int v : revedge[u]) {
                    --children[v];
                    tag[v].emplace_back(label[u]);
                    if(!children[v]) {
                        label[v] = T.check(tag[v]);
                        Bucket[label[v]].emplace_back(v);
                    }
                }
            }
            std::cout << std::endl;
        }
    }
} ;

int main(int argc, char *argv[]) {
    if(argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <graph-file>" << std::endl;
        std::cerr << "Format of graph-file:\n"
                  << "  First line contains two numbers, n and m. n = |V(G)|, m = |E(G)|\n"
                  << "  Followed by m lines, two numbers each line, representing a directed edge.\n";
        return 1;
    }
    GraphSimplify gs;
    if(!gs.loadFromFile(argv[1])) {
        std::cerr << "Failed to load graph." << std::endl;
        return 1;
    }
    gs.simplfy();
    return 0;
}