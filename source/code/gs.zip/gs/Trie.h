#include <unordered_map>
#include <vector>
#include <memory>

using Vec = std::vector<int>;
class Trie {
private :
    int index = 0;
    struct Node {
        int label;
        std::unordered_map<int, std::shared_ptr<Node> > map;
        Node (int x = -1) { label = x; }
        ~ Node () { map.clear(); }
    } ;

    std::shared_ptr<Node> root;
public :
    Trie() { root = std::make_shared<Node>(0); }
    void init() {
        root.reset();
        root = std::make_shared<Node>(0);
    }
    ~ Trie() {
        root.reset();
    }
    int check(const Vec &vec) {
        std::shared_ptr<Node> now = root;
        for(auto x : vec) {
            if(now->map.find(x) == now->map.end()) {
                now->map.insert(std::make_pair(x, std::make_shared<Node>()));
            }
            now = now->map[x];
        }
        if(now->label == -1) now->label = ++index;
        return now->label;
    }
} ;